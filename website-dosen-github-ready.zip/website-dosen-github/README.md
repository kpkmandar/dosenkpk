# Website Akademik Dosen

Website personal akademik berbasis HTML, CSS, dan JavaScript.

## Fitur
- Profil akademik
- Pengajaran
- Penelitian
- Publikasi
- Bahan ajar
- Blog akademik
- Kontak profesional
- Responsive mobile

## Deploy GitHub Pages

1. Upload seluruh folder ke repository GitHub
2. Masuk Settings
3. Pages
4. Pilih Branch main
5. Save

Website akan aktif melalui GitHub Pages.

## Struktur

```
index.html
assets/
  images/
```
